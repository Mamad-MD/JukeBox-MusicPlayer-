#ifndef WAR_BEGINS_RANDOMGENERATOR_H
#define WAR_BEGINS_RANDOMGENERATOR_H
#include <random>
#include <vector>
using namespace std;

int generateRandom(int start, int end);

//extern vector<int> usedRandomNums;
#endif //WAR_BEGINS_RANDOMGENERATOR_H
